<!DOCTYPE html>
<html lang="ru">
<head>
     <? require 'osnova/setup.php'; ?>
</head>

<body>
     <header>
          <? require 'osnova/header1.php'; ?>
     </header>

     <main class="container">
          <? require 'templates/user.php'; ?>
     </main>
</body>

</html>