<!DOCTYPE html>
<html lang="ru">

<head>
     <? require 'osnova/setup.php'; ?>
</head>

<body>

     <header id="header" >

      <? require 'osnova/header.php'; ?>
     </header>

     <main class="container">
          <? require 'glavnaya/main.php'; ?>
     </main>
</body>

</html>