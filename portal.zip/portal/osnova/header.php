<link rel="stylesheet" href="style.css">

    <header class="headerglav">
        <h1>Сделаем вместе<br> лучше!</h1>
        <p>Прием заявок на устранение проблем в городе</p>
    </header>

